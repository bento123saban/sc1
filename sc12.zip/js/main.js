                                                                                                                

const formGroups    = document.querySelectorAll('.confirm-group'),
    lanjutkan       = document.querySelector('#lanjutkan'),
    literBox        = document.querySelector('.liter-box'),
    formLiter       = document.querySelector('.form-liter'),
    literClose      = document.querySelector('#liter-close'),
    liter           = document.querySelector('#liter')



window.addEventListener('DOMContentLoaded', function (e) {
    formGroups.forEach(form => {
        const sx    = form.querySelector('.sx'),
            tx      = form.querySelector('.tx')
        sx.onclick  = function (e) {
            this.querySelector('i').classList.add('clr-green', 'br-green')
            sx.classList.add('active')
            sx.classList.remove('inactive')
            tx.classList.add('inactive')
            tx.classList.remove('active')
        }
        tx.onclick  = function (e) {
            this.querySelector('i').classList.add('clr-red', 'br-red')
            tx.classList.add('active')
            tx.classList.remove('inactive')
            sx.classList.add('inactive')
            sx.classList.remove('active')
        }
    })
    lanjutkan.onclick = function (e) {
        literBox.classList.remove('dis-none')
        formLiter.classList.remove('dis-none')
    }
    literClose.onclick = function (e) {
        literBox.classList.add('dis-none')
        formLiter.classList.add('dis-none')
    }
    liter.addEventListener('keyup', function (e) {
        
    })
})
