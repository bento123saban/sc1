                                                                                                                

const formGroups    = document.querySelectorAll('.confirm-group'),
    lanjutkan       = document.querySelector('#lanjutkan'),
    literBox        = document.querySelector('.liter-box'),
    formLiter       = document.querySelector('.form-liter'),
    literClose      = document.querySelector('#liter-close'),
    liter           = document.querySelector('#liter'),
    literError      = document.querySelector(".liter-error"),
    submit          = document.querySelector("#submit"),
    lanjutkanText   = document.querySelector("#lanjutkan-text")



window.addEventListener('DOMContentLoaded', function (e) {
    formGroups.forEach(form => {
        const sx    = form.querySelector('.sx'),
            tx      = form.querySelector('.tx')
        sx.onclick  = function (e) {
            sx.parentElement.dataset.value = "true"
            sx.parentElement.classList.remove("highlight")
            this.querySelector('i').classList.add('clr-green', 'br-green')
            sx.classList.add('active')
            sx.classList.remove('inactive')
            tx.classList.add('inactive')
            tx.classList.remove('active')

            let param = true
            formGroups.forEach(group => (group.dataset.value == "") ? param = false : "")
            if(param) return lanjutkan.classList.remove("cancel")
            return lanjutkan.classList.add("cancel")
        }
        tx.onclick  = function (e) {
            tx.parentElement.dataset.value = "false"            
            sx.parentElement.classList.remove("highlight")
            this.querySelector('i').classList.add('clr-orange', 'br-orange')
            tx.classList.add('active')
            tx.classList.remove('inactive')
            sx.classList.add('inactive')
            sx.classList.remove('active')
            
            let param = true
            formGroups.forEach(group => (group.dataset.value == "") ? param = false : "")
            if(param) return lanjutkan.classList.remove("cancel")
            return lanjutkan.classList.add("cancel")
        }
    })
    lanjutkan.onclick = function (e) {
        if(this.classList.contains("cancel")) {
            formGroups.forEach(group => (group.dataset.value == "") ? group.classList.add("highlight") : group.classList.remove("highlight"))
            lanjutkanText.classList.add("active")
            return lanjutkanText.textContent = "Pastikan semua pilihan terpilih"
        }
        literBox.classList.remove('dis-none')
        formLiter.classList.remove('dis-none')
    }
    literClose.onclick = function (e) {
        literBox.classList.add('dis-none')
        formLiter.classList.add('dis-none')
    }
    liter.addEventListener('keyup', function (e) {
        if(this.value == 0) {
            this.value = 0
            literError.classList.add("dis-none")
        }
        if(this.value == "") {
            literError.textContent = "Masukan angka"
            literError.classList.remove("dis-none")
        }
        if (this.value.length >= 1) return literError.classList.add("dis-none")
        this.value = "" + this.value.replace(/[^0-9]/g, '')
    })
})
